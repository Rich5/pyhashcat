from HashcatWrapper import *
